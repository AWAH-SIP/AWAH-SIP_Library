
Network Problems
****************

IP Address Change
=================
Please see the wiki `Handling IP Address Change`_. Note that the guide is written using PJSUA API as a reference.

.. _`Handling IP Address Change`: https://trac.pjsip.org/repos/wiki/IPAddressChange

Blocked/Filtered Network
========================
Please refer to the wiki `Getting Around Blocked or Filtered VoIP Network`_.

.. _`Getting Around Blocked or Filtered VoIP Network`: https://trac.pjsip.org/repos/wiki/get-around-nat-blocked-traffic-filtering

